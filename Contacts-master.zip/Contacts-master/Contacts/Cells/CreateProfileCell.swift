//
//  CreateProfileCell.swift
//  Contacts
//
//  Created by Johnny Perdomo on 12/19/18.
//  Copyright © 2018 Johnny Perdomo. All rights reserved.
//

import UIKit

class CreateProfileCell: UITableViewCell {

    @IBOutlet weak var txtLabel: UILabel!
    @IBOutlet weak var actionImageIcon: UIImageView!
    @IBOutlet weak var actionImageIconShadow: CustomUIView!
    
}
