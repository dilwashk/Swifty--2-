//
//  IsFavoriteEnum.swift
//  Contacts
//
//  Created by Johnny Perdomo on 12/24/18.
//  Copyright © 2018 Johnny Perdomo. All rights reserved.
//

import Foundation

enum IsFavoriteEnum {
    case yes
    case no
}
