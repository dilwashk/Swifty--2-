//
//  ProfileTypeEnum.swift
//  Contacts
//
//  Created by Johnny Perdomo on 12/20/18.
//  Copyright © 2018 Johnny Perdomo. All rights reserved.
//

import Foundation

enum ProfileTypeEnum {
    case createNew
    case view
}
